import sys
import json
import time
from bson import json_util
import boto3


#constants
def lambda_handler(event, context):
    alarm_prefix='ArdentELBStatusAlarm-'
    alarm_version='v1.0.0'
    
    cw_client = boto3.client('cloudwatch')
    ec2_client = boto3.client('ec2')
    sns_arn= 'arn:aws:sns:us-east-1:950417325420:Ardent-AWS-Alerts-Topic'
    
    instance_alarms=[]
    cw_response = cw_client.describe_alarms( AlarmNamePrefix=alarm_prefix)


    for alarm in cw_response['MetricAlarms']:
        instance_alarms.append(alarm['AlarmName'].replace(alarm_prefix,''))
    if 'NextToken' in cw_response:
        got_all_alarms = False
        next_token = cw_response['NextToken']
    else:
        got_all_alarms = True
    while got_all_alarms != True:
        cw_response = cw_client.describe_alarms( AlarmNamePrefix=alarm_prefix, NextToken=next_token)
        for alarm in cw_response['MetricAlarms']:
            instance_alarms.append(alarm['AlarmName'].replace(alarm_prefix,''))
        if 'NextToken' in cw_response:
            got_all_alarms = False
            next_token = cw_response['NextToken']
        else:
            got_all_alarms = True
    resp = ec2_client.describe_instances()
    print (len(resp['Reservations']))


    for instance_res in resp['Reservations']:
        instance_IDs = instance_res['Instances']
        for instance in instance_IDs:
            instance_ID = instance['InstanceId']
            if instance_ID not in instance_alarms:
                print (instance_ID + ' needs alarm!!!')
                resp = cw_client.put_metric_alarm(
                    AlarmName=alarm_prefix + instance_ID,
                    AlarmDescription=alarm_prefix + alarm_version,
                    ActionsEnabled=True|False,
                    AlarmActions=[
                        sns_arn
                    ],
                    MetricName='StatusCheckFailed',
                    Namespace='AWS/EC2',
                    Statistic='Maximum',
                    Dimensions=[
                        {
                            'Name': 'InstanceId',
                            'Value': instance_ID
                        },
                    ],
                    Period=60,
                    EvaluationPeriods=2,
                    Threshold=1.0,
                    ComparisonOperator='GreaterThanOrEqualToThreshold'
                )
                print (resp)
            else:
                print (instance_ID + ' already has an alarm')
